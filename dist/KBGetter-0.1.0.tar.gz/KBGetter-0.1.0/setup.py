# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['kbgetter']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.10.0,<5.0.0',
 'requests>=2.26.0,<3.0.0',
 'tinydb>=4.5.2,<5.0.0']

setup_kwargs = {
    'name': 'kbgetter',
    'version': '0.1.0',
    'description': 'Download FreshService articles to a local machine',
    'long_description': None,
    'author': 'Matt Kasfeldt',
    'author_email': 'matt.kasfeldt@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/mkasfeldt/KBgetter',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
